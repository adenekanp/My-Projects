using System;
using System.Net;
using System.IO;

namespace CurrencyConverter
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                // Get the exchange rate data from the API
                string url = "https://api.exchangeratesapi.io/latest?base=USD&symbols=EUR";
                HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
                HttpWebResponse response = (HttpWebResponse)request.GetResponse();
                string responseBody = "";
                using (Stream stream = response.GetResponseStream())
                {
                    StreamReader reader = new StreamReader(stream);
                    responseBody = reader.ReadToEnd();
                }

                // Parse the exchange rate data from the JSON response
                double exchangeRate = double.Parse(responseBody.Substring(16, 6));

                // Prompt the user for the amount of dollars to convert
                Console.Write("Enter the amount of dollars to convert: ");
                double dollars = double.Parse(Console.ReadLine());

                // Convert the dollars to euros using the exchange rate
                double euros = dollars * exchangeRate;

                // Display the result to the user
                Console.WriteLine(dollars + " dollars is equal to " + euros.ToString("0.00") + " euros.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
        }
    }
}

// My form design keeps showing errors and I am not sure what to do. I seeked counsel from a senior colleague while writing this code and I am surprised the code has no errors but the Design has several.